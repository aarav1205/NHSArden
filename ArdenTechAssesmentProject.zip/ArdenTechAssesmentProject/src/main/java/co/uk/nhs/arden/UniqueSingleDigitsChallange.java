package co.uk.nhs.arden;

import java.util.HashSet;
import java.util.Set;

public class UniqueSingleDigitsChallange {

	public static void main(String[] args) {
		for(int a = 0; a <= 9; a++) {
			for(int b = 0; b <= 9; b++) {
				for(int c = 0; c <= 9; c++) {
					if(b!=c && a!=b && a!=c) { //Validate a,b,c are unique values
						int d = (((a*10)+b) * c) / 10;
						int e = (((a*10)+b) * c) % 10;
						if(d!=e && d<=9 && d>=0 && a!=d && b!=d && c!=d && a!=e && b!=e && c!=e ) { //Validate a,b,c,d,e are unique values
							for(int f = 0; f <= 9; f++) {
								for(int g = 0; g <= 9; g++) {
									if(f!=g) {
										int m = (((d*10)+e) + ((f*10)+g)) / 10;
										int n = (((d*10)+e) + ((f*10)+g)) % 10;
										if(m!=n && m<=9 && m>=0) {
											Set<Integer> uniqueValue = new HashSet<>();
											if(uniqueValue.add(a) && uniqueValue.add(b) && uniqueValue.add(c) && uniqueValue.add(d)&& 
											uniqueValue.add(e) && uniqueValue.add(f) && uniqueValue.add(g) && uniqueValue.add(m) &&
											uniqueValue.add(n))  //Validate if all variables are unique
											{
												System.out.println("a: " + a + ", b: " + b + ", c: " + c
														+ ", d: " + d + ", e: " + e + ", f: " + f + ", g: "
														+ g + ", m: " + m + ", n: " + n);
											}

										}

									}

								}
							}
						}

					}

				}
			}
		}

	}

}
