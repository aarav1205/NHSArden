package co.uk.nhs.arden;

public class SnippetsChallenge {
	public static void main(String[] args) {

		getArrayIndexOutOfBoundsException();
		getNullPointerException();
		reverseString();
		removeWhiteSpace();
	}

	public static void getArrayIndexOutOfBoundsException() {
		try {
			int[] numbers = { 1, 2, 3, 4 };
			int index = 6;
			int value = numbers[index];
			System.out.println("Value = " + value);
		} catch (ArrayIndexOutOfBoundsException ex) {
			System.out.println("Array Index Out Of Bounds Exception occurred !!! ----" + ex.getMessage());
		}

	}

	public static void getNullPointerException() {
		try {
			String str = null;
			int strLength = str.length();
			System.out.println("strLength = " + strLength);
		} catch (NullPointerException ex) {
			System.out.println("Null Pointer Exception occurred !!! ----" + ex.getMessage());
		}

	}

	public static void reverseString() {
		String str = "NICOR";
		String revStr = new StringBuilder(str).reverse().toString();
		System.out.println(str + " ------Reverse is-------- " + revStr);
	}

	public static void removeWhiteSpace() {
		String str = "National Institute For Cardiovascular Outcomes Research";
		String finalString = str.replaceAll("\\s+", "");
		System.out.println(str + "------StringAfterRemovedWhiteSpaces -------------- " + finalString);
	}

}
