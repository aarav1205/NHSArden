package co.uk.nhs.arden;

public class SnippetsChallenge {
	public static void main(String[] args) {

		getArrayIndexOutOfBoundsException();
		getNullPointerException();
		reverseString("NICOR");
		removeWhiteSpace("National Institute For Cardiovascular Outcomes Research");
	}

	//Array index out of bounds exception 
	public static void getArrayIndexOutOfBoundsException() {
		try {
			int[] numbers = { 1, 2, 3, 4 };
			int index = 6;
			int value = numbers[index];
			System.out.println("Value = " + value);
		} catch (ArrayIndexOutOfBoundsException ex) {
			System.out.println("Array Index Out Of Bounds Exception occurred !!! ----" + ex.getMessage());
		}

	}

	//Null pointer exception
	public static void getNullPointerException() {
		try {
			String str = null;
			int strLength = str.length();
			System.out.println("strLength = " + strLength);
		} catch (NullPointerException ex) {
			System.out.println("Null Pointer Exception occurred !!! ----" + ex.getMessage());
		}

	}

	//The reverseString method takes a string as input, converts it to a StringBuilder, 
	//and then calls the reverse method of StringBuilder to reverse the characters
	public static void reverseString(String str) {
		String revStr = new StringBuilder(str).reverse().toString();
		System.out.println(str + " ------Reverse is-------- " + revStr);
	}

	//The removeWhitespace method takes a string as input and uses the replaceAll method to replace 
	//all occurrences of one or more whitespace characters (\s+) with an empty string
	public static void removeWhiteSpace(String str) {
		String finalString = str.replaceAll("\\s+", "");
		System.out.println(str + "------StringAfterRemovedWhiteSpaces -------------- " + finalString);
	}

}
