package co.uk.nhs.arden;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class ReadSalesRecordFile {

	// Please modify csv file path before running this code.
	private static final String SALES_RECORDS_CSV = "C:\\dev\\SalesRecords.csv";
	private static final String CSV_DELIMITER = ",";
	private static final String MM_DD_YYYY = "MM/dd/yyyy";

	public static void main(String[] args) {

		List<Item> recordList = readSalesRecord();
		calcSumOfProfitsPerEachItemSold(recordList);
		calcYearMoreOrdersReceived(recordList);
		calAvgDaysBetweenOrderAndShipDate(recordList);
	}

	private static List<Item> readSalesRecord() {
		List<Item> recordList = new ArrayList<>();
		String csvFile = SALES_RECORDS_CSV;
		String line;
		String csvDelimiter = CSV_DELIMITER;
		int iteration = 0;
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			while ((line = br.readLine()) != null) {
				if (iteration == 0) {
					iteration++;
					continue;
				}
				String[] values = line.split(csvDelimiter);
				if (values.length > 1) {
					try {
						// System.out.println("--values---"+Arrays.toString(values));
						Item item = new Item(values[0].trim(), values[1].trim(), values[2].trim(), values[3].trim(),
								values[4].trim(), new SimpleDateFormat(MM_DD_YYYY).parse(values[5].trim()),
								Integer.parseInt(values[6].trim()),
								new SimpleDateFormat(MM_DD_YYYY).parse(values[7].trim()),
								Integer.parseInt(values[8].trim()), Double.parseDouble(values[9].trim()),
								Double.parseDouble(values[10].trim()), Double.parseDouble(values[11].trim()),
								Double.parseDouble(values[12].trim()), Double.parseDouble(values[13].trim()));
						// System.out.println("---item---"+item);
						recordList.add(item);
					} catch (NumberFormatException ex) {
						System.out.println(ex.getMessage());
					} catch (ParseException ex) {
						System.out.println(ex.getMessage());
					}

				}

			}
			System.out.println("---Read the Sales record file---");
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
		return recordList;
	}

	private static void calcSumOfProfitsPerEachItemSold(List<Item> recordList) {

		double sumOfProfitsPerEachItemSold = recordList.stream().map(e -> e.totalProfit() / e.unitsSold()).reduce(0.0,
				Double::sum);
		System.out.println("Calculate sum of profits per each item sold-----" + sumOfProfitsPerEachItemSold);
	}

	private static void calcYearMoreOrdersReceived(List<Item> recordList) {

		Map<Integer, List<Item>> yearMoreOrdersReceivedList = recordList.parallelStream().collect(Collectors
				.groupingBy(e -> e.orderDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate().getYear()));
		Map<Integer, Integer> yearMoreOrdersReceived = new HashMap<>();
		for (Integer key : yearMoreOrdersReceivedList.keySet()) {
			yearMoreOrdersReceived.put(key,
					yearMoreOrdersReceivedList.get(key).stream().map(e -> e.unitsSold()).reduce(0, Integer::sum));
		}

		Integer maxOrders = Integer.MIN_VALUE;
		Integer maxOrdersYear = null;

		for (Integer key : yearMoreOrdersReceived.keySet()) {
			// System.out.println(key+"-----------"+yearMoreOrdersReceived.get(key));
			if (yearMoreOrdersReceived.get(key) > maxOrders) {
				maxOrders = yearMoreOrdersReceived.get(key);
				maxOrdersYear = key;
			}
		}
		System.out.println("Calculate in which year there was more orders received--------" + maxOrdersYear);

	}

	private static void calAvgDaysBetweenOrderAndShipDate(List<Item> recordList) {

		double avgDaysBetweenOrderAndShipDate = recordList.stream()
				.map(e -> TimeUnit.MILLISECONDS.toDays(e.shipDate().getTime() - e.orderDate().getTime()))
				.reduce((long) 0, Long::sum) / recordList.size();

		System.out.println(
				"Calculate average days between order date and ship date----" + avgDaysBetweenOrderAndShipDate);
	}

}

record Item(String region, String country, String itemType, String salesChannel, String orderPriority, Date orderDate,
		int orderID, Date shipDate, int unitsSold, double unitPrice, double unitCost, double totalRevenue,
		double totalCost, double totalProfit) {
}
