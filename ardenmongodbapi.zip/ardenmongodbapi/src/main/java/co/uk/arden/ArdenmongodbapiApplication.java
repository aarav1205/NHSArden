package co.uk.arden;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArdenmongodbapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArdenmongodbapiApplication.class, args);
	}

}
