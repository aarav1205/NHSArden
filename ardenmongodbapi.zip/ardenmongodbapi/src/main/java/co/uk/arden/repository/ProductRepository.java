package co.uk.arden.repository;
import org.springframework.data.mongodb.repository.MongoRepository;
import co.uk.arden.entity.Product;

public interface ProductRepository extends MongoRepository<Product, String> {
    // Additional custom queries can be added here if needed 
	}

