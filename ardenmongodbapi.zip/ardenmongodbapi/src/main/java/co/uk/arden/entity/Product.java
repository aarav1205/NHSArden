package co.uk.arden.entity;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@AllArgsConstructor
@Getter
@Setter
@Document(collection = "products")
public class Product {
	@Id
	@NotBlank(message = "Id must not be blank")
	private String id;
	@NotBlank(message = "Product name must not be blank")
	private String name;
	@Min(value = 0, message = "Product price must be greater than 0")
	@Max(value = 9999, message = "Product price must be less than 10000")
	private double price;
}
