package co.uk.arden.exception;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ApplicationRuntimeException extends RuntimeException {
  /**
   * Serial Version ID
   */
  private static final long serialVersionUID = 1L;
  /**
   * @param message Message to set in exception
   */
  public ApplicationRuntimeException(final String message) {
    super(message);
  }
}
