package co.uk.arden.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import co.uk.arden.entity.Product;
import co.uk.arden.exception.ApplicationRuntimeException;
import co.uk.arden.repository.ProductRepository;
import java.util.List;

@Service
public class ProductService {
    private final ProductRepository productRepository;

    @Autowired
    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(String id) {
        return productRepository.findById(id).orElseThrow(() -> new ApplicationRuntimeException("Product Not Found with id "+id));
    }

    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    public Product updateProduct(Product product) {
        return productRepository.save(product);
    }

    public void deleteProduct(String id) {
    	if (!productRepository.existsById(id)) {
			throw new ApplicationRuntimeException("Product Not Found with id "+id);
		}
        productRepository.deleteById(id);
    }
}
