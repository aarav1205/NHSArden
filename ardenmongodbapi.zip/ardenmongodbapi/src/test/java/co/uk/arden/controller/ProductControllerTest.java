package co.uk.arden.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import co.uk.arden.entity.Product;
import co.uk.arden.exception.ApplicationRuntimeException;
import co.uk.arden.service.ProductService;

@ExtendWith(MockitoExtension.class)
class ProductControllerTest {

	private List<Product> productList = List.of(
			new Product("1","bread",3400.0)
			,new Product("2","butter",40.0));
	
	@Mock
	private ProductService productServiceMock;
	
	@InjectMocks
	private  ProductController productController;
	
	
	@DisplayName("Test Get All Products")
	@Test
	void testGetAllProducts() {
		when(productServiceMock.getAllProducts()).thenReturn(productList);
		ResponseEntity<?> result = productController.getAllProducts();	
		assertEquals(HttpStatus.OK,result.getStatusCode());
		assertEquals(productList, result.getBody());
	}
	
	@DisplayName("Test Get  Product by ID")
	@Test
	void testGetProductById() {
		when(productServiceMock.getProductById(anyString())).thenReturn(productList.get(0));
		ResponseEntity<?> result = productController.getProductById("1");	
		assertEquals(HttpStatus.OK,result.getStatusCode());
		assertEquals(productList.get(0), result.getBody());
		verify(productServiceMock).getProductById("1");
		
	}
	
	@DisplayName("Test Negative case, Product not found by ID")
	@Test
	void testNegativeCaseGetProductById() {
		when(productServiceMock.getProductById(anyString())).thenThrow(ApplicationRuntimeException.class);
		Assertions.assertThrows(ApplicationRuntimeException.class, ()->{ productController.getProductById("11");});
	}

	@DisplayName("Test Create  Product")
	@Test
	void testCreateProduct() {
		when(productServiceMock.createProduct(any())).thenReturn(productList.get(0));
		ResponseEntity<?> result = productController.createProduct(productList.get(0));	
		assertEquals(HttpStatus.CREATED,result.getStatusCode());
		assertEquals(productList.get(0), result.getBody());
		verify(productServiceMock).createProduct(productList.get(0));
	}
	
	@DisplayName("Test Update  Product")
	@Test
	void testUpdateProduct() {
		when(productServiceMock.updateProduct(any())).thenReturn(productList.get(0));
		ResponseEntity<?> result = productController.updateProduct(productList.get(0));	
		assertEquals(HttpStatus.OK,result.getStatusCode());
		assertEquals(productList.get(0), result.getBody());
		verify(productServiceMock).updateProduct(productList.get(0));
	}

	@DisplayName("Test Delete Product")
	@Test
	void testDeleteProduct() {
		doNothing().when(productServiceMock).deleteProduct(anyString());
		ResponseEntity<?> result = productController.deleteProduct("1");	
		assertEquals(HttpStatus.OK,result.getStatusCode());
		verify(productServiceMock).deleteProduct("1");
	}

}
