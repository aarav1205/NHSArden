package co.uk.arden;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArdenmongodbapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
